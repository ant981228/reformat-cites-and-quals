import configparser
import os
import pyperclip
import anthropic

# Define the path to the .ini file
config_path = os.path.join(os.path.dirname(__file__), 'config.ini')

# Load the configuration file with the specified encoding (UTF-16)
config = configparser.ConfigParser()
config.read(config_path, encoding='utf-16')

# Retrieve the API key from the configuration file
if not config.has_section('API') or not config.has_option('API', 'key'):
    raise KeyError("Missing 'API' section or 'key' in config file.")
api_key = config.get('API', 'key')

# Create an instance of the Anthropic client
client = anthropic.Anthropic(api_key=api_key)

# Get the text from the clipboard
clipboard_content = pyperclip.paste()

# Prepare the prompt for the model
system_message = """
I have pasted in a long chunk of names and qualifications/institutional affiliations. This is the author list on a report. I want you to format their qualifications as follows:
FirstName1 LastName1, Role at Institution, notable qualification, notable qualification, award; FirstName2 LastName2, Role at Institution, notable qualification, notable qualification, award; ... FirstNameN LastNameN, Role at Institution, notable qualification, notable qualification, award,
Return no text other than reformatted name and qualifications, all on one line. Do not add any biographical information that is not pasted. Do not include punctuation at the end. If the qualifications are in another language, translate them to English. 
"""

# Send the request to the Anthropic API using `messages.create`
response = client.messages.create(
    model="claude-3-5-sonnet-20240620",
    max_tokens=1000,
    temperature=0,
    system=system_message,
    messages=[{'role': 'user', 'content': clipboard_content}]
)

# Extract the reformatted result
formatted_content = response.content

# Copy the result back to the clipboard
pyperclip.copy(formatted_content)

# Print a success message
print("Reformatted content has been copied to the clipboard.")
